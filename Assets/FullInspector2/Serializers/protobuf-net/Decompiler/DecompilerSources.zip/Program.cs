﻿using ICSharpCode.Decompiler;
using ICSharpCode.Decompiler.Ast;
using Microsoft.CSharp;
using Mono.Cecil;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;

namespace Decompiler {
    public class SimpleAssemblyResolver : IAssemblyResolver {
        public AssemblyDefinition Resolve(string fullName, ReaderParameters parameters) {
            return null;
        }

        public AssemblyDefinition Resolve(string fullName) {
            return null;
        }

        public AssemblyDefinition Resolve(AssemblyNameReference name, ReaderParameters parameters) {
            return null;
        }

        public AssemblyDefinition Resolve(AssemblyNameReference name) {
            return null;
        }
    }
    class Program {

        static void Main(string[] args) {
            try {
                if (args.Length == 0) {
                    var outputPath = "output.cs";
                    var dllPath = @"C:\Users\jacob_000\Desktop\Unity Projects\FullInspector\Decompiler\ProtoBufNetPrecompiledSeriaizer.dll";
                    var searchDirectories = new List<string>() {
                        @"C:\Users\jacob_000\Desktop\Unity Projects\FullInspector\Library\ScriptAssemblies",
                        @"C:\Users\jacob_000\Desktop\Unity Projects\FullInspector\Assets\FullInspector2\Serializers\protobuf-net\DLLs",
                        @"C:\Program Files (x86)\Unity\Editor\Data\Managed"
                    };

                    Decompile(outputPath, dllPath, searchDirectories);
                }

                else {
                    var outputPath = args[0];
                    var dllPath = args[1];
                    var searchDirectories = args.Skip(2).ToList();

                    Decompile(outputPath, dllPath, searchDirectories);
                }
            }
            catch (Exception e) {
                Console.Error.WriteLine(e);
                Console.Error.WriteLine();
                Console.Error.WriteLine("Arguments have length " + args.Length + " with value " + string.Join(" ", args));
            }
        }

        private static void Decompile(string outputPath, string modulePath, List<string> searchDirectories) {
            List<string> log = new List<string>();

            var module = ModuleDefinition.ReadModule(modulePath);

            BaseAssemblyResolver resolver = (BaseAssemblyResolver)module.AssemblyResolver;
            foreach (var dir in searchDirectories) resolver.AddSearchDirectory(dir);

            DecompilerContext context = new DecompilerContext(module);

            StringBuilder stringBuilder = new StringBuilder();
            stringBuilder.AppendLine("public class ProtoBufNetPrecompiledSeriaizer : TypeModel {");

            TypeDefinition type = module.GetTypes().ToList()[1].Resolve();
            context.CurrentType = type;

            foreach (FieldDefinition field in type.Fields) {
                AstBuilder builder = new AstBuilder(context);
                builder.DecompileMethodBodies = true;
                builder.AddField(field);

                ITextOutput output = new PlainTextOutput();
                builder.GenerateCode(output);

                stringBuilder.Append(output.ToString());
            }

            foreach (MethodDefinition method in type.Methods) {

                AstBuilder builder = new AstBuilder(context);
                builder.DecompileMethodBodies = true;
                builder.AddMethod(method);

                ITextOutput output = new PlainTextOutput();
                builder.GenerateCode(output);

                var outputStr = output.ToString();

                {
                    /*
                       UnityObjectSurrogate<RuntimeAnimatorController> unityObjectSurrogate = (UnityObjectSurrogate<!0>)runtimeAnimatorController;
                     to
                       var unityObjectSurrogate = (UnityObjectSurrogate<RuntimeAnimatorController>)runtimeAnimatorController;
                     */
                    Regex regex = new Regex(@"(?<whitespace>\s+)(?<typename>[\w@_][^\s]*?)\s+(?<varname>[^\s]+?)\s*=\s*\(.*\!\d+.*\)(?<result>.*?);");
                    foreach (Match match in regex.Matches(outputStr)) {
                        var whitespace = match.Groups["whitespace"].Value;
                        var typename = match.Groups["typename"].Value;
                        var varname = match.Groups["varname"].Value;
                        var result = match.Groups["result"].Value;
                        var replacement = string.Format("{0}var {1} = ({2}){3};", whitespace, varname, typename, result);

                        log.Add("Replaced");
                        log.Add("\t" + match.Value.Trim());
                        log.Add("with");
                        log.Add("\t" + replacement.Trim());
                        log.Add("");
                        outputStr = outputStr.Replace(match.Value, replacement);
                    }
                }
                {
                    /*
                     * gUIElement = (!0)unityObjectSurrogate;
                     * to
                     * gUIElement = (GUIElement)unityObjectSurrogate;
                     */

                    Regex regex = new Regex(@"(?<whitespace>\s+)(?<varname>[\w@_][^\s]*?)\s*=\s*\(!0\)(?<result>.*?);");

                    foreach (Match match in regex.Matches(outputStr)) {
                        var whitespace = match.Groups["whitespace"].Value;
                        var varname = match.Groups["varname"].Value;
                        var result = match.Groups["result"].Value;

                        // HACK: looks like ILSpy just uses the typename as the variable name, but with
                        //       the first character as lower
                        //string typename = char.ToUpper(varname[0]) + varname.Substring(1);
                        //if (varname[0] == '@') {
                        //    typename = typename.Substring(1);
                        //}
                        string typename = FindVariableType(method, varname);

                        string replacement = string.Format("{0}{1} = ({2}){3};", whitespace, varname, typename, result);
                        log.Add("Replaced");
                        log.Add("\t" + match.Value.Trim());
                        log.Add("with");
                        log.Add("\t" + replacement.Trim());
                        log.Add("");

                        outputStr = outputStr.Replace(match.Value, replacement);
                    }
                }


                {
                    /*
                     * val == null
                     * to
                     * ReferenceEquals(val, null)
                     * 
                     * (and also !=)
                     */

                    // Why is this replacement necessary? Unity overloads operator== for
                    // UnityEngine.Object types. operator== is not available for usage in
                    // code running outside of the main thread, which is where serialization can
                    // occur.

                    /*
                    Regex regex = new Regex(@"(?<whitespace>\s*)(?<varname>[\w@_][^\s]*?)\s*(?<op>(==)|(!=))\s*null");
                    foreach (Match match in regex.Matches(outputStr)) {
                        string whitespace = match.Groups["whitespace"].Value;
                        string varname = match.Groups["varname"].Value;

                        string op = match.Groups["op"].Value;
                        string opValue = op == "==" ? "true" : "false";

                        string replacement = string.Format("{0}ReferenceEquals({1}, null) == {2}", whitespace, varname, opValue);
                        log.Add("Replaced");
                        log.Add("\t" + match.Value.Trim());
                        log.Add("with");
                        log.Add("\t" + replacement.Trim());
                        log.Add("");

                        outputStr = outputStr.Replace(match.Value, replacement);
                    }
                    */
                }
                {
                    /*
                     * WrapMode result;
                     * to
                     * WrapMode result = default(WrapMode);
                     */
                    Regex regex = new Regex(@"(?<whitespace>\s+)(?<typename>\w[^\s^(^)^,^:]*)\s+(?<varname>[\w_@][^\s]*?);");
                    foreach (Match match in regex.Matches(outputStr)) {
                        string whitespace = match.Groups["whitespace"].Value;
                        string typename = match.Groups["typename"].Value;
                        string varname = match.Groups["varname"].Value;

                        // skip keywords, like return foo;
                        if (IsKeyWord(typename)) {
                            continue;
                        }

                        string replacement = string.Format("{0}{1} {2} = default({1});", whitespace, typename, varname);
                        log.Add("Replaced");
                        log.Add("\t" + match.Value.Trim());
                        log.Add("with");
                        log.Add("\t" + replacement.Trim());
                        log.Add("");

                        outputStr = outputStr.Replace(match.Value, replacement);
                    }

                }

                // Correct the virtual function definitions
                {
                    outputStr = outputStr.Replace("new int GetKeyImpl", "override int GetKeyImpl");
                    outputStr = outputStr.Replace("internal new void Serialize", "override void Serialize");
                    outputStr = outputStr.Replace("internal new object Deserialize", "override object Deserialize");
                }

                stringBuilder.Append(outputStr);
            }

            // Remove usings
            stringBuilder = new StringBuilder(ReformatUsingStatements(stringBuilder.ToString()));

            stringBuilder.Append("}");


            StringBuilder final = new StringBuilder();
            final.AppendLine("//");
            final.AppendLine("// WARNING: FULL INSPECTOR GENERATED FILE. CHANGES WILL NOT BE SAVED");
            final.AppendLine("//");
            final.AppendLine("// This file has been automatically generated by Full Inspector. Any changes made will not be saved");
            final.AppendLine("// across regenerations.");
            final.AppendLine("//");
            final.AppendLine("// If you're wondering how this file was generated, there a few steps involved. protobuf-net will");
            final.AppendLine("// generate a precompiled serializer, but protobuf-net only operates on the MSIL level. The");
            final.AppendLine("// outputted DLL has a dependency on Assembly-CSharp and the like, which breaks Unity's build");
            final.AppendLine("// process when doing AOT compiles.");
            final.AppendLine("//");
            final.AppendLine("// To deal with this, NRefactory is used to convert the DLL into C#. The raw NRefactory output has");
            final.AppendLine("// some compiler errors, so Full Inspector applies a number of post-processing steps to correct");
            final.AppendLine("// these errors.");
            final.AppendLine("// ");
            final.AppendLine("// The rest of these comments contain the post processing steps that Full Inspector");
            final.AppendLine("// has applied to the source.");
            final.AppendLine("//");
            final.AppendLine("#if false // Full Inspector transform log contained in this #if");
            foreach (var line in log) {
                final.Append("// ");
                final.AppendLine(line);
            }
            final.Append("#endif");
            final.AppendLine();
            final.AppendLine();
            final.Append("#pragma warning disable // disable all warnings");
            final.AppendLine();
            final.AppendLine();
            final.Append(stringBuilder.ToString());

            File.WriteAllText(outputPath, final.ToString());
        }

        /// <summary>
        /// Extracts all inline using statements in the file and moves them to the beginning.
        /// </summary>
        private static string ReformatUsingStatements(string str) {
            HashSet<string> usings = new HashSet<string>();

            Regex regex = new Regex("using .+;" + Environment.NewLine);
            foreach (Match match in regex.Matches(str)) {
                if (usings.Add(match.Value)) {
                    str = str.Replace(match.Value, "");
                }
            }

            StringBuilder result = new StringBuilder(str.Length);
            foreach (var usingStatement in usings) {
                result.AppendLine(usingStatement.Trim());
            }
            result.AppendLine();
            result.Append(str);

            return result.ToString();
        }

        private static bool IsKeyWord(string str) {
            string[] keywords = @"abstract as base bool break byte case catch char checked class
                const continue decimal default delegate do double else enum event explicit extern
                false finally fixed float for foreach goto if implicit in int interface internal is
                lock long namespace new null object operator out override params private protected
                public readonly ref return sbyte sealed short sizeof stackalloc static string
                struct switch this throw true try typeof uint ulong unchecked unsafe ushort using
                virtual void volatile while".Split(new string[] { " ", Environment.NewLine, "\t", "\n", "\r\n" }, StringSplitOptions.RemoveEmptyEntries);
            return Array.IndexOf(keywords, str) >= 0;
        }

        private static string FindVariableType(MethodDefinition method, string variableName) {
            string lowerVarName = variableName.ToLower();
            if (lowerVarName[0] == '@') lowerVarName = lowerVarName.Substring(1);

            foreach (var param in method.Parameters) {
                if (param.Name == variableName) {
                    return CSharpName(param.ParameterType);
                }
                if (param.ParameterType.Name.ToLower() == lowerVarName) {
                    return CSharpName(param.ParameterType);
                }
            }

            foreach (var variable in method.Body.Variables) {
                if (variable.Name == variableName) {
                    return CSharpName(variable.VariableType);
                }
                if (variable.VariableType.Name.ToLower() == lowerVarName) {
                    return CSharpName(variable.VariableType);
                }
            }

            throw new InvalidOperationException("Unable to find variable with name " + variableName);
        }

        /// <summary>
        /// Returns a pretty name for the type in the style of one that you'd see in C#.
        /// </summary>
        public static string CSharpName(TypeReference type) {
            if (type.Name == "Void") return "void";

            if (type.IsGenericInstance == false) {
                return type.FullName;
            }

            // original code taken from http://stackoverflow.com/a/17376472
            string name = type.Name;
            if (string.IsNullOrEmpty(type.Namespace) == false) {
                name = type.Namespace + "." + name;
            }

            var sb = new StringBuilder();

            GenericInstanceType genericType = (GenericInstanceType)type;

            sb.Append(name.Substring(0, name.IndexOf('`')));
            sb.Append("<");
            sb.Append(string.Join(", ", genericType.GenericArguments
                                            .Select(t => CSharpName(t))
                                            .ToArray()));
            sb.Append(">");

            return sb.ToString();
        }
    }
}
